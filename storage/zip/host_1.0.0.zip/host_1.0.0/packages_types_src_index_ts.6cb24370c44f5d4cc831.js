"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkhost"] = self["webpackChunkhost"] || []).push([["packages_types_src_index_ts"],{

/***/ "../../packages/types/src/index.ts":
/*!*****************************************!*\
  !*** ../../packages/types/src/index.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Modules: () => (/* reexport safe */ _modules__WEBPACK_IMPORTED_MODULE_0__.Modules)
/* harmony export */ });
/* harmony import */ var _modules__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modules */ "../../packages/types/src/modules.ts");


/***/ }),

/***/ "../../packages/types/src/modules.ts":
/*!*******************************************!*\
  !*** ../../packages/types/src/modules.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Modules: () => (/* binding */ Modules)\n/* harmony export */ });\nvar Modules = /*#__PURE__*/function (Modules) {\n  Modules[\"HOST\"] = \"HOST\";\n  Modules[\"MAIL_SENDER\"] = \"MAIL_SENDER\";\n  return Modules;\n}({});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi4vLi4vcGFja2FnZXMvdHlwZXMvc3JjL21vZHVsZXMudHMiLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ob3N0Ly4uLy4uL3BhY2thZ2VzL3R5cGVzL3NyYy9tb2R1bGVzLnRzP2M4ZGEiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gTW9kdWxlcyB7XG4gICAgSE9TVCA9ICdIT1NUJyxcbiAgICBNQUlMX1NFTkRFUiA9ICdNQUlMX1NFTkRFUicsXG59XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///../../packages/types/src/modules.ts\n");

/***/ })

}]);